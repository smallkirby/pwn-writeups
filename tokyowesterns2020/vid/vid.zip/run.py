#!/usr/bin/python3
import pty
pty.spawn("./vid")

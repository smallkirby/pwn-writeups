The stretch.img has bunch of flags which look like pbctf{..} but those are not the actual flags on remote. So, don't waste time submitting them on the challenge server. 

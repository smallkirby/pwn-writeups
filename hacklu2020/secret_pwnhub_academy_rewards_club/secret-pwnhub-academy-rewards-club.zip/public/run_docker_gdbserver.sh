#!/bin/bash
docker run -u root -p 4444:4444 -it sparc-1 /chall/run_socat.sh 1
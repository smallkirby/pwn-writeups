#!/bin/bash
docker build -t sparc-1 .
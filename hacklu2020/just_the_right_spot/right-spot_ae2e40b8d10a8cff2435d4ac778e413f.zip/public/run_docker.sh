#!/bin/bash
docker run -p 4444:4444 -it right_spot:latest $@
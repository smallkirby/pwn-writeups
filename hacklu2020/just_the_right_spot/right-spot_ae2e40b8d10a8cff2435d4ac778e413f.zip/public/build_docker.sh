#!/bin/bash
docker build -t right_spot:latest .
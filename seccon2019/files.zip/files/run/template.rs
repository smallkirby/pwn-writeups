extern crate mal;

fn main() {
    println!("{}", f());
}

/** code **/